# IKT-Projekt
 
## Képek és ikonok forrása:

- Pexels: https://www.pexels.com/
- Pixabay: https://pixabay.com/
- Picsum: https://picsum.photos/
- Freepik: https://www.freepik.com/
- Flaticon: https://www.flaticon.com/

:joy: